<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, APIKEY, Access-Control-Allow-Headers");
    header("Cache-Control: must-revalidate");
    $offset = 60 * 60 * 24 * 3;
    $ExpStr = "Expires: ". gmdate("D, d M Y H:i:s", time() + $offset) . "GMT";
    header($ExpStr);

    require ('Constants.php');
    require ('SubstTemplate.php');
    
    use App\Web\Service\REST\API\Constants as apiconstant;
    
    $results = array();
    $requiredfields = array ('recipient', 'subject', 'message', 'replyto', 'replytoName', 'from', 'fromName');
    
    $apiKey = strip_tags (trim ($_SERVER['HTTP_APIKEY']));
    if ($_SERVER['REQUEST_METHOD'] != 'POST')
    {
        http_response_code (apiconstant::METHOD_NOT_ALLOWED);
        exit (json_encode (array ("error" => apiconstant::HTTP_METHOD_INVALID, 'code' => apiconstant::METHOD_NOT_ALLOWED)));
    }
    
    if ($_SERVER['CONTENT_TYPE'] != 'application/json' || ! isset ($_SERVER['HTTP_APIKEY']))
    {
        http_response_code (apiconstant::NOT_ACCEPTABLE);
        exit (json_encode (array ("error" => apiconstant::NOT_ACCEPTABLE_HEADERS, 'code' => apiconstant::NOT_ACCEPTABLE)));
    }
    
    if ($apiKey != apiconstant::API_KEY)
    {
        http_response_code (apiconstant::UNAUTHORIZED_REQUEST);
        exit (json_encode (array ("error" => apiconstant::INVALID_TOKEN, 'code' => apiconstant::UNAUTHORIZED_REQUEST)));
    }
    
    $postData = json_decode (file_get_contents ("php://input"), true);
    if (empty ($postData))
    {
        http_response_code (apiconstant::BAD_REQUEST);
        exit (json_encode (array ("error" => apiconstant::MISSING_PARAMETERS, 'code' => apiconstant::BAD_REQUEST)));
    }
    
    if (! is_array($postData['messages']))
    {
        http_response_code (apiconstant::BAD_REQUEST);
        exit (json_encode (array ("error" => apiconstant::MISSING_PARAMETERS, 'code' => apiconstant::BAD_REQUEST)));
    }
    
    foreach ($requiredfields as $key)
    {
        if (! array_key_exists ($key, $postData['messages']) || empty ($postData['messages'][$key]))
		{
		    http_response_code (apiconstant::BAD_REQUEST);
            exit (json_encode (array ("error" => apiconstant::MISSING_PARAMETERS, 'code' => apiconstant::BAD_REQUEST)));
		}
    }
    
    if (isset ($postData['data'])) $postData['messages']['message'] = App\Web\Pages\SubstTemplate::GetSubstitutedString (base64_decode ($postData['messages']['message']), $postData['data']);
    $msg = $postData['messages'];
    
    // preparing the email
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-type: text/html; charset=iso-8859-1';
    $headers[] = 'Reply-To: '.$msg['replytoName'].' <'.$msg['replyto'].'>';
    $headers[] = (! empty ($msg['fromName'])) ? 'From: '.$msg['fromName'].' <'.$msg['from'].'>' : 'From: '.$msg['replytoName'].' <'.$msg['from'].'>';

    # split the recipients (incase there's multiple recipients)
    $recipients = preg_split ('/\,/', $msg['recipient']);
    
    if (is_array ($recipients))
    {
        foreach ($recipients as $recipient)
        {
            // send the email
            if (! filter_var ($recipient, FILTER_VALIDATE_EMAIL) || ! mail (trim ($recipient), $msg['subject'], $msg['message'], implode ("\r\n", $headers), "-odb -f ".$msg['from']))
            {
                $error = (! filter_var ($recipient, FILTER_VALIDATE_EMAIL)) ? 'Invalid Email Address' : error_get_last()['message'];
                $results[] = array ('recipient' => trim ($recipient), 'status' => 'failed', 'error' => $error, 'code' => 110);
            }
            else
            {
                $results[] = array ('recipient' => trim ($recipient), 'status' => apiconstant::SUCCESS, 'message' => base64_encode ($msg['message']));
            }
        }
    }
    else
    {
        if (! filter_var ($recipient, FILTER_VALIDATE_EMAIL) || ! mail (trim($recipients), $msg['subject'], $msg['message'], implode("\r\n", $headers), "-odb -f ".$msg['from']))
        {
            $error = (! filter_var ($recipient, FILTER_VALIDATE_EMAIL)) ? 'Invalid Email Address' : error_get_last()['message'];
            $results[] = array ('recipient' => trim ($recipients), 'status' => 'failed', 'error' => $error, 'code' => 110);
        }
        else
        {
            $results[] = array ('recipient' => trim ($recipients), 'status' => apiconstant::SUCCESS, 'message' => base64_encode ($msg['message']));
        }
    }
    
    http_response_code (apiconstant::REQUEST_OK);
    exit (json_encode (array ('results' => apiconstant::SUCCESS, 'messages' => $results)));
    
?>