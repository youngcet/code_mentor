<?php

    namespace App\Web\Service\REST\API;
    
    class Constants
    {
        public const API_KEY = 'ed47d3d45bd9e52b7fdb06f7';
        
        public const SUCCESS = 'success';
        public const INVALID_TOKEN = 'Invalid API Key';
        
        // status codes
        public const REQUEST_OK = '200';
        public const BAD_REQUEST = '400';
        public const UNAUTHORIZED_REQUEST = '401';
        public const FORBIDDEN_REQUEST = '403';
        public const NOT_FOUND_REQUEST = '404';
        public const METHOD_NOT_ALLOWED = '405';
        public const NOT_ACCEPTABLE = '406';
        public const INTERNAL_SERVER_ERROR = '500';
        
        public const HTTP_METHOD_INVALID = 'HTTP request method not allowed';
        public const HTTP_CONTENT_TYPE_INVALID = 'Invalid Content Type';
        public const MISSING_PARAMETERS = 'Missing required parameters';
        public const FORBIDDEN_REQUEST_ERROR = 'Forbidden Request - 403';
        public const NOT_ACCEPTABLE_HEADERS = 'Missing required headers';
        
        public const INVALID_INPUTS = 'Invalid Input';
        
        public const XPOSEDSTORE_LOG = 'xposedstoreapi.log';
        public const EMPTY = '';
        public const INVALID_TYPE = 'Invalid Type';
        public const INVALID_FORMAT = 'Invalid Format';
        public const REQUIRED_MININUM_LENGTH = 'Minimum Required Length';
        public const REQUIRED_LENGTH = 'Required Length';
        public const MAXIMUM_LENGTH = 'Maximum Length';
        public const CELL_LENGTH = 10;
        public const MINIMUN_LENGTH = 4;
        
    }
?>