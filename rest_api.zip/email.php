<?php

    require ('Restful.php');

    date_default_timezone_set ('Africa/Johannesburg');

    $messages = array ('messages' => array (
        'recipient' => 'to@domain.co.za', 
        'subject' => 'New Invoice', 
        'message' => base64_encode (file_get_contents ('invoice.html')), 
        'from' => 'from@address', 
        'replytoName' => 'Yung Cet',
        'fromName' => 'no-reply',
        'replyto' => 'replyto@address'
    ),
    'data' => array (
                'items' => array 
                    (
                        array ('{item.name}' => 'item 1', '{item.qty}' => '1', '{item.price}' => '10', '{item.total}' => '10'),
                        array ('{item.name}' => 'item 2', '{item.qty}' => '3', '{item.price}' => '40', '{item.total}' => '120'),
                        array ('{item.name}' => 'item 3', '{item.qty}' => '2', '{item.price}' => '50', '{item.total}' => '100'),
                    ),
                '{customer.name}' => 'Cedric Maenetja',
                '{customer.number}' => '0600000000',
                '{customer.email}' => 'testemail@domain.com',
                '{billing.address}' => '20 street no<br/>my suburb<br/>my city<br/>postal code',
                '{invoice.date}' => date ('d F Y', time()),
                '{invoice.duedate}' => date ('d F Y', strtotime (date ('d F Y', time()). ' + 10 days')),
                '{invoice.number}' => 123456789,
                '{invoice.subtotal}' => 230.00, 
                '{invoice.vat}' => 0, 
                '{invoice.total}' => 230.00,
                '{additional.info}' => 'Thank you for your business. Please remit all payments to:',
                '{bank.details}' => 'Bank Name<br/>Account Number<br/>Account Type',
            )
    );
    
    $sendMail = App\Web\Service\REST\API::APIcall ('ed47d3d45bd9e52b7fdb06f7', 'POST', 'https://domain.co.za/api/v2/email/send_messages', $messages);
    print_r($sendMail);
?>